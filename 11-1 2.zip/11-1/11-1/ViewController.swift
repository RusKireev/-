//
//  ViewController.swift
//  11-1
//
//  Created by Рустам Киреев on 24.09.2022.
//

import UIKit

class ViewController: UIViewController{

    let labelSelect = UILabel()
    
    @IBOutlet weak var textView: CustomSegment!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        labelSelect.textColor = .black
        labelSelect.frame = CGRect(x: 150, y: 150, width: 70, height: 70)
        labelSelect.backgroundColor = .red
        textView.delegate = self
        view.addSubview(labelSelect)
        
    }
}

extension ViewController: CustomSegmentDelegate{
    func selectSegment(_ message: String){
        labelSelect.text = message
    }
}
