//
//  ClockButSegView.swift
//  11-1
//
//  Created by Рустам Киреев on 27.09.2022.
//

import UIKit

@IBDesignable
class ClockButSegView: UIView {

    var isSetuped = false
    
    @IBInspectable var markerSize: CGFloat = 3
    @IBInspectable var markerLength: CGFloat = 12
    @IBInspectable var markerColor: UIColor = UIColor.blue
    
    @IBInspectable var hourLineOffset: CGFloat = 30
    @IBInspectable var hourLineSize: CGFloat = 6
    @IBInspectable var hourLineColor: UIColor = UIColor.green
    
    @IBInspectable var minuteLineOffset: CGFloat = 25
    @IBInspectable var minuteLineSize: CGFloat = 8
    @IBInspectable var minuteLineColor: UIColor = UIColor.blue
    
    @IBInspectable var secondLineOffset: CGFloat = 20
    @IBInspectable var secondLineSize: CGFloat = 2
    @IBInspectable var secondLineColor: UIColor = UIColor.purple
    
    @IBInspectable var hours: CGFloat = 7{
        didSet { updateHours() }
    }
    @IBInspectable var minutes: CGFloat = 5{
        didSet { updateMinutes() }
    }
    @IBInspectable var second: CGFloat = 9{
        didSet { updateSeconds() }
    }
    
    @IBInspectable var roundedViewColor = UIColor.yellow
    
    private let topMarker = UIView()
    private let leftMarker = UIView()
    private let rightMarker = UIView()
    private let bottomMarker = UIView()
    
    private let hourLine = UIView()
    private let minuteLine = UIView()
    private let secondLine = UIView()
    
    private let roundedView = UIView()
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let w = frame.size.width
        let h = frame.size.height
        
        hourLine.layer.anchorPoint = CGPoint(x: 0.5, y: 1)
        hourLine.frame = CGRect(x: w / 2 - hourLineSize / 2, y: hourLineOffset, width: hourLineSize, height: h/2 - hourLineOffset)
        hourLine.backgroundColor = hourLineColor
        
        minuteLine.layer.anchorPoint = CGPoint(x: 0.5, y: 1)
        minuteLine.frame = CGRect(x: w / 2 - minuteLineSize / 2, y: minuteLineOffset, width: minuteLineSize, height: h/2 - minuteLineOffset)
        minuteLine.backgroundColor = minuteLineColor
        
        secondLine.layer.anchorPoint = CGPoint(x: 0.5, y: 1)
        secondLine.frame = CGRect(x: w / 2 - secondLineSize / 2, y: secondLineOffset, width: secondLineSize, height: h/2 - secondLineOffset)
        secondLine.backgroundColor = secondLineColor
        
        topMarker.frame = CGRect(x: w / 2 - markerSize / 2, y: 0, width: markerSize, height: markerLength)
        bottomMarker.frame = CGRect(x: w / 2 - markerSize / 2, y: h - markerLength, width: markerSize, height: markerLength)
        leftMarker.frame = CGRect(x: 0, y: h / 2 - markerSize / 2, width: markerLength, height: markerSize)
        rightMarker.frame = CGRect(x: w - markerLength, y: h / 2 - markerSize / 2, width: markerLength, height: markerSize)
        
        for v in [topMarker, leftMarker, rightMarker, bottomMarker]{
            v.backgroundColor = markerColor
        }
        
        roundedView.backgroundColor = roundedViewColor
        roundedView.frame = CGRect(x: w / 2 - 8, y: h / 2 - 8, width: 16, height: 16)
        roundedView.layer.cornerRadius = 8
        
        layer.cornerRadius = frame.size.width / 2
        
        updateHours()
        updateMinutes()
        updateSeconds()
        
        if isSetuped { return }
        isSetuped = true
        
        addSubview(hourLine)
        addSubview(minuteLine)
        addSubview(secondLine)

        for v in [topMarker, leftMarker, rightMarker, bottomMarker, hourLine, minuteLine, secondLine, roundedView]{
            addSubview(v)
        }
        

        updateHours()
        updateMinutes()
        updateSeconds()
    }
    
    func updateHours(){
        let angle = CGFloat.pi * 2 * (hours / CGFloat(12))
        hourLine.transform = CGAffineTransform(rotationAngle: angle)
    }
    
    func updateMinutes(){
        let angle = CGFloat.pi * 2 * (minutes / CGFloat(12))
        minuteLine.transform = CGAffineTransform(rotationAngle: angle)
    }
    func updateSeconds(){
        let angle = CGFloat.pi * 2 * (second / CGFloat(12))
        secondLine.transform = CGAffineTransform(rotationAngle: angle)
    }
   
    
}



